package day.six;

/*
 Abstract Class:- If a class contains atleast 1 abstract method then it is abstract class.
 --------------
 Abstract Method:- If a method does not contains body.
 ----------------
 Points
 ------
 	1. Abstract class and abstract method must be declared by using abstract keyword
 	2. We cannot create object to the abstract class but we can create a reference variable
 	3. If an abstract class inherits into sub class that must override all abstract methods otherwise declare sub class
 	   as abstract class.
 	4. An abstract class may also contains concrete methods
 	  
 */
abstract class Maths {
	public void sum(int a,int b){  //concrete method
		System.out.println("The sum is : " + (a + b));
	}
	abstract public void sub(int a,int b);
	abstract public void mul(int a,int b);//in order to call the child methods from parent reference
}
class Calculate extends Maths {
	@Override
	public void sub(int a, int b) {									
		System.out.println("The sub is : " + (a - b));
	}																
	public void mul(int a, int b) {
		System.out.println("The mul is : " + (a * b));
	}
	public void div(int a, int b) {
		System.out.println("The div is : " + (a / b));
	}
}

public class AbstractDemo1 {
	public static void main(String[] args) {
		Calculate cal = new Calculate();
		cal.sum(10, 20);
		cal.sub(10, 5);
		cal.mul(10, 5);
		
		Maths maths = new Calculate();
		maths.sum(10, 20);
		maths.sub(10, 5);
		maths.mul(10, 5);
	}

}
