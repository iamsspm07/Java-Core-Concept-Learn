package day.three;

public class ConcatSumOfDigitsOfDecimal {

	public static String concateSumOfDigits(double num){
		String number = num+"";
		String decParts[] = number.split("\\.");
		int leftSum = sumOfDigits(Integer.parseInt(decParts[0]));
		int rightSum = sumOfDigits(Integer.parseInt(decParts[1]));
		if(rightSum != 0)
			return leftSum+":"+rightSum;
		else
			return leftSum+"";
	}
	public static int sumOfDigits(int num){
		int sum = 0;
		while(num > 0){
			sum += num % 10;
			num = num / 10;
		}
		return sum;
	}
	public static void main(String[] args) {
		double num = 28;
		System.out.println(concateSumOfDigits(num));

	}

}
