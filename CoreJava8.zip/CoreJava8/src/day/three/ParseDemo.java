package day.three;

public class ParseDemo {

	public static void main(String[] args) {
		String str1 = "100";
		String str2 = "200";
		
		System.out.println(Integer.parseInt(str1) + Integer.parseInt(str2)); 

	}

}
