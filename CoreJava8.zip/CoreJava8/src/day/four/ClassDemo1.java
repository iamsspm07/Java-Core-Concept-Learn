package day.four;

/* Constructor:- It is a special method which calls automatically when object is created.
	Rules:-
	-----
	1) Name must be same as it's class name
	2) No return type (not even void)

Default: it is automatically available in every class but if u write paramterized constructor then u must write default

Advantage:- To initialize the object properties
*/
class Sample {
	private int a,b;//instance variable only accessible inside the class
	
	public Sample(){ //public accessible outside the class and outside package where as no access modifier means default
					 //default is accesible with in the package to any class
		
		System.out.println("Hi! This is a constructor...");
	}
	
	public Sample(int a,int b){ //local variables
		this.a = a;
		this.b = b;
	}
	public void read(int a,int b){ //local variables
		this.a = a;
		this.b = b;
	}
	public void show(){
		System.out.println(a);
		System.out.println(b);
	}
	public void sum(){
		System.out.println("The sum is : "+ (a+b));
	}
}

public class ClassDemo1 {
	public static void main(String[] args) {
		Sample sample1 = new Sample();//default constructor
		sample1.read(10,20);//sample1.a = 10  sample1.b=20
		sample1.show();
		sample1.sum();
		
		Sample sample2 = new Sample(100,200);//parameterized constructor
		sample2.show();
		sample2.sum();
		
	}
}

/*

 1. object
 2. class
 3. private variables
 4. public methods
 5. this keyword
 6. constructor

 */

