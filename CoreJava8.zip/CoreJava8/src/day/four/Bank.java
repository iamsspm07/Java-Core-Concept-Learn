package day.four;

public class Bank {

	private Customer customersList[] = new Customer[20];
	int counter = 0;

	public int addCustomer(String firstName,String lastName,String address,double amount){
		Customer customer = new Customer(firstName,lastName,address,amount);
		customersList[counter] = customer;
		counter++;
		return customer.getId();
	}

	public Customer[] getAllCustomers(){
		return customersList;
	}

	public Customer getCustomerById(int id){
		for(Customer customer : customersList){
			if(customer.getId() == id){
				return customer;
			}
		}
		return null;
	}

	public String deposit(int id,double amount){
		for(Customer customer : customersList){
			if(customer!=null && customer.getId() == id){
				customer.setBalance(customer.getBalance() + amount);
				return "Deposit Successful : "+customer.getBalance();
			}
		}
		return "Customer not found";
	}
	public String withdraw(int id,double amount){
		for(Customer customer : customersList){
			if(customer!=null && customer.getId() == id){
				if(customer.getBalance() - amount >= 1000){
					customer.setBalance(customer.getBalance() - amount);
					return "Withdraw Successful : "+customer.getBalance();
				}
				else{
					return "Insufficient Funds in Account";
				}
			}
		}
		return "Invalid Customer";
	}
}
