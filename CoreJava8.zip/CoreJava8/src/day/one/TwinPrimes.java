package day.one;

public class TwinPrimes {

	public static boolean isPrime(int n){
		if(n < 2)
			return false;
		
		for(int i = 2; i <= n / 2; i++){		//1 and itself 	if i found atleast 1 factor is retur false
			if(n % i == 0)
				return false;
		}
		return true;
	}
	
	public static String twinPrimes(int Min, int Max){
		String result="";
		if(Min < 0 )
			return "Error";
		if(Min > 100 || Max > 100)
			return "Error";
		if(Min >= Max)
			return "Error";
		
		for(int i = Min; i <= Max -2; i++){
			if(isPrime(i) && isPrime(i+2))
				result += i +","+(i + 2)+";";
		}
		
		if(result.length() == 0)
			return "No Twin Primes Found";
		
		return result;
	}
	
	public static void main(String[] args) {
		System.out.println(twinPrimes(-1, 1));
		System.out.println(twinPrimes(99, 100));
		System.out.println(twinPrimes(99, 50));
		System.out.println(twinPrimes(5, 30));
	}
}
