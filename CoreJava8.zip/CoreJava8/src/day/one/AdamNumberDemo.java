package day.one;

public class AdamNumberDemo {

	public static boolean isAdamNumber(int n){
		int square = square(n);//144
		int revNum1 = square(getReverse(n)); //441
		int num2 = getReverse(revNum1);
		return square == (num2);		
	}
	
	public static int getReverse(int n){
		int rev = 0;
		while(n > 0){
			rev = (rev * 10) + n % 10;
			n = n / 10;
		}
		return rev;
	}
	public static int square(int n){
		return n * n;
	}
	
	public static void main(String[] args) {
		
		System.out.println(isAdamNumber(12));
	}
}
