package day.one;

import java.util.Scanner;

public class HelloWorld {

	public static void hello(String name){
		System.out.println("Hello World : "+name);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name : " );
		String name = sc.nextLine();
		hello(name);
		System.out.println("Main...");
	}
}
