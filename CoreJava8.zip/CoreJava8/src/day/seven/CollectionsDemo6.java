package day.seven;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class CollectionsDemo6 {

	public static void main(String[] args) {
		
		//It maintains the order of insertion and duplicates are allowed
		List <String>list = new ArrayList<String>(); //no type no size
		
		list.add("INDIA");
		list.add("AUSTRALIA");
		list.add("ENGLAND");
		list.add("USA");
		list.add("CHINA");
		list.add("DUBAI");
		list.add("INDIA");
		list.add("BANGLADESH");
		System.out.println(list);
		
		//list.remove("CHINA");
		//list.remove(4);
		Collections.sort(list);
		
		for(String str : list){
			System.out.println(str);
		}
		
		//Iterator
		System.out.println("Elements by iterator in forward direction..");
		Iterator it = list.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		
		System.out.println("Elements by ListIterator..in forward direction..");
		ListIterator lit = list.listIterator();
		while(lit.hasNext()){
			System.out.println(lit.next());
		}
		System.out.println("Elements by ListIterator..in backward direction..");
		while(lit.hasPrevious()){
			System.out.println(lit.previous());
		}
	}
}

/*
Collection (Group of Objects)
-----------------------------
Array


Drawbacks
---------
1) size if fixed (int a[] = new int[5]);
2) similler data type only possible
3) no underlaying data structure methods




*/