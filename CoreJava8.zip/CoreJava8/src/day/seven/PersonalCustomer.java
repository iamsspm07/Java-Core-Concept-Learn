package day.seven;

public class PersonalCustomer extends Customer {
	
	private String homePhone;
	private String workPhone;
	
	
	public PersonalCustomer(){}
	
	public PersonalCustomer(String firstName, String lastName, String address, double balance,String homePhone, String workPhone) {
		super(firstName, lastName, address, balance);
		this.homePhone = homePhone;
		this.workPhone = workPhone;
	}
	
	public double calculateInterest(){
		return (balance * 4.0 ) / 100;
	}
	
	public void showDetails(){
		System.out.println("Id" + id);
		System.out.println("Full Name : "+ getFullName());
		System.out.println("Address : " + address);
		System.out.println("Balance : " + balance);
		System.out.println("Total Interest :" + calculateInterest());
		System.out.println("Home Phone : " + homePhone);
		System.out.println("Work Phone : " + workPhone);
	}
	
	public String getHomePhone() {
		return homePhone;
	}
	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}
	public String getWorkPhone() {
		return workPhone;
	}
	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}
	
}
