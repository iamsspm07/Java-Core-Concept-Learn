package day.seven;

import java.util.ArrayList;
import java.util.List;

public class CollectionsDemo7 {

	public static void main(String[] args) {
		List <Integer> list = new ArrayList<Integer>();
		list.add(101);
		list.add(102);
		list.add(103);
		list.add(104);
		list.add(105);
		list.add(101);
		list.add(106);

		System.out.println(list);
		//list.remove(0);
		list.remove(new Integer(101));
		System.out.println(list);
		int sum = 0;
		for(Integer x : list){
			sum += x;
		}
		System.out.println("The sum is : " + sum);
	}

}
