package day.seven;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class CollectionsDemo8 {

	public static void main(String[] args) {
		
		List <Employee>list = new ArrayList<Employee>(); //no type no size
		
		Employee e5 = new Employee(5,"SURYA",5555.55);
		list.add(e5);
		Employee e3 = new Employee(3,"KOHLI",7777.77);
		list.add(e3);
		Employee e1 = new Employee(1,"PASHA",9999.99);
		list.add(e1);
		Employee e4 = new Employee(4,"PANDYA",6666.66);
		list.add(e4);
		Employee e2 = new Employee(2,"SACHIN",8888.88);
		list.add(e2);
		
		System.out.println(list);
		
		Collections.sort(list);//by defult it is sorting with id
		
		System.out.println(list);
		
		Collections.sort(list,new SortBySal());
		System.out.println(list);
	}
}

/*
Collection (Group of Objects)
-----------------------------
Array


Drawbacks
---------
1) size if fixed (int a[] = new int[5]);
2) similler data type only possible
3) no underlaying data structure methods




*/