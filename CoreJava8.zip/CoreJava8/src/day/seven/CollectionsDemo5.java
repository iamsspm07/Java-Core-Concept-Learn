package day.seven;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class CollectionsDemo5 {

	public static void main(String[] args) {
		
		//It maintains the order of insertion and no duplicates are allowed
		Set <String>set = new TreeSet<String>(); //no type no size
		
		set.add("INDIA");
		set.add("AUSTRALIA");
		set.add("ENGLAND");
		set.add("USA");
		set.add("CHINA");
		set.add("DUBAI");
		set.add("INDIA");
		set.add("BANGLADESH");
		System.out.println(set);
		
		set.remove("CHINA");
		
		for(String str : set){
			System.out.println(str);
		}
	}
}

/*
Collection (Group of Objects)
-----------------------------
Array


Drawbacks
---------
1) size if fixed (int a[] = new int[5]);
2) similler data type only possible
3) no underlaying data structure methods




*/