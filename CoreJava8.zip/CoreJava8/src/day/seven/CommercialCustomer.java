package day.seven;

public class CommercialCustomer extends Customer {

	String contactPersonName;
	String contactPersonPhone;

	public CommercialCustomer(){}
	
	public void showDetails(){
		System.out.println("Id" + id);
		System.out.println("Full Name : "+ getFullName());
		System.out.println("Address : " + address);
		System.out.println("Balance : " + balance);
		System.out.println("Total Interest :" + calculateInterest());
		System.out.println("Contact Person Name : " + contactPersonName);
		System.out.println("Contact Person Phone : " + contactPersonPhone);
	}
	
	public CommercialCustomer(String firstName, String lastName, String address, double balance,String contactPersonName, String contactPersonPhone) {
		super(firstName, lastName, address, balance);
		this.contactPersonName = contactPersonName;
		this.contactPersonPhone = contactPersonPhone;
	}
	
	public double calculateInterest(){
		return (balance * 1.2 ) / 100;
	}
	
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactPersonPhone() {
		return contactPersonPhone;
	}
	public void setContactPersonPhone(String contactPersonPhone) {
		this.contactPersonPhone = contactPersonPhone;
	}

}
