package day.eight;


/* 
 finally block is the guaranteed execution block and it is most useful for closing resources of the program.
 */
class Demo{
	public void A(){
		System.out.println("showA is started...");
		try {
		throw new ArithmeticException();
		}catch(ArithmeticException e){
			System.out.println("Inside catch block of A");
		}
		finally{
			System.out.println("Finally of A");
		}
		System.out.println("A is ended...");
	}
	public void B(){
		System.out.println("showB is started...");
		try {
		
		}catch(ArithmeticException e){
			System.out.println("Inside catch block of B");
		}
		finally{
			System.out.println("Finally of B");
		}
		System.out.println("B is ended...");
	}
	public void C(){
		System.out.println("showC is started...");
		try {
			return;
		}catch(ArithmeticException e){
			System.out.println("Inside catch block of C");
		}
		finally{
			System.out.println("Finally of C");
		}
		System.out.println("C is ended...");
	}
}


public class Finally {
	public static void main(String[] args) {
		Demo demo = new Demo();
		demo.A();
		demo.B();
		demo.C();	
	}
}
