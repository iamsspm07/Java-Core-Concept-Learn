package day.eight;

class AgeException extends Exception {
	public String toString(){
		return "Invalid Age Entered...";
	}
}

class Person {
	private int age;
	private String name;
	public Person(){}
	public Person(int age, String name) throws AgeException { //propagating exception handling responsibilities to caller
		if(age >= 1 && age <= 150){
			this.age = age;
			this.name = name;
		}
		else{
				throw new AgeException();
		}
	}
	public void showDetails(){
		System.out.println("Age : "+age);
		System.out.println("Name : "+ name);
	}
}

public class ExceptionsDemo4 {
	public static void main(String[] args) throws AgeException {
		Person p1 = new Person(25,"SACHIN");
		p1.showDetails();

		Person p2 = new Person(-25,"DHONI");
		p2.showDetails();
	}
}

/*
Exceptions Handling
-------------------
An exception is a runtime error which terminates the program abnormally.

ATM
----
1) Insert Carad
2) Enter pin
3) Account Opened
4) Read Request
5) Check Availability
6) Withdraw if avl
7) say sorry if not avl
8) close account
9) eject card



1. try
2. catch
3. throw
4. throws



 */