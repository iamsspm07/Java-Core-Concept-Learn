package day.eight;

import java.util.ArrayList;
import java.util.List;

class InsufficientBalanceException extends Exception {
	public String toString(){
		return "Insufficient Funds...";
	}
}

public class Bank {

	private List<Customer> customersList = new ArrayList<Customer>();

	public int addPersonalCustomer(String firstName,String lastName,String address,double amount,String homePhone, String workPhone){
		PersonalCustomer customer = new PersonalCustomer(firstName,lastName,address,amount,homePhone,workPhone);
		customersList.add(customer);
		return customer.getId();
	}
	public int addCommercialCustomer(String firstName,String lastName,String address,double amount, String contactPersonName, String contactPersonPhone){
		CommercialCustomer customer = new CommercialCustomer(firstName,lastName,address,amount,contactPersonName, contactPersonPhone);
		customersList.add(customer);
		return customer.getId();
	}

	public List<Customer> getAllCustomers(){
		return customersList;
	}

	public Customer getCustomerById(int id){
		for(Customer customer : customersList){ 
			if(customer.getId() == id){
				return customer;
			}
		}
		return null;
	}

	public String deposit(int id,double amount){
		for(Customer customer : customersList){
			if(customer.getId() == id){
				customer.setBalance(customer.getBalance() + amount);
				return "Deposit Successful : "+customer.getBalance();
			}
		}
		return "Customer not found";
	}
	public String withdraw(int id,double amount) throws InsufficientBalanceException{
		for(Customer customer : customersList){
			if(customer.getId() == id){
				if(customer.getBalance() - amount >= 1000){
					customer.setBalance(customer.getBalance() - amount);
					return "Withdraw Successful : "+customer.getBalance();
				}
				else{
					throw new InsufficientBalanceException();
				}
			}
		}
		return "Invalid Customer";
	}
	
	public String transfers(int fromId,int toId, double amount) throws InsufficientBalanceException {
		Customer c1 = getCustomerById(fromId);
		Customer c2 = null;
		if(c1!=null){
			 c2 = getCustomerById(toId);
		} else {
			return "From Customer does not exist"; 
		}
		if(c2!=null){
			String result1 = withdraw(c1.getId(),amount);
			if(result1.contains("Withdraw Successful")){ 
				deposit(c2.getId(),amount);
			}
		} else {
			return "To Customer does not exist";
		}
		return "Transfers is successful..";
	}
}






