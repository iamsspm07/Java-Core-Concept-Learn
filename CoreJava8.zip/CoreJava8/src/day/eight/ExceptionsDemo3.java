package day.eight;

public class ExceptionsDemo3 {

	public static void main(String[] args) {

		int a[] = new int[5];
		try {
			System.out.println("The division is : " + 10 / a[0]);
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(ArithmeticException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("Program ended successfully...");				
	}
}

/*
Exceptions Handling
-------------------
An exception is a runtime error which terminates the program abnormally.

ATM
----
1) Insert Carad
2) Enter pin
3) Account Opened
4) Read Request
5) Check Availability
6) Withdraw if avl
7) say sorry if not avl
8) close account
9) eject card




 */