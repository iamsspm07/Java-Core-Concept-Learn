package day.eight;

public class CommercialCustomer extends Customer {

	String contactPersonName;
	String contactPersonPhone;

	public CommercialCustomer(){}
	
	public String getDetails(){
		return "Id" + id+"\n"+"Full Name : "+ getFullName()+"\n"+
		"Address : " + address+"\n"+"Balance : " + balance+"\n"+"Total Interest :" 
				+ calculateInterest()+"\n"+"Contact Person Name : " + contactPersonName+
				"\n"+"Contact Person Phone : " + contactPersonPhone;
	}
	
	public CommercialCustomer(String firstName, String lastName, String address, double balance,String contactPersonName, String contactPersonPhone) {
		super(firstName, lastName, address, balance);
		this.contactPersonName = contactPersonName;
		this.contactPersonPhone = contactPersonPhone;
	}
	
	public double calculateInterest(){
		return (balance * 1.2 ) / 100;
	}
	
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactPersonPhone() {
		return contactPersonPhone;
	}
	public void setContactPersonPhone(String contactPersonPhone) {
		this.contactPersonPhone = contactPersonPhone;
	}

}
