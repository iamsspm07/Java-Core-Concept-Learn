package day.eight;

public class PersonalCustomer extends Customer {
	
	private String homePhone;
	private String workPhone;
	
	
	public PersonalCustomer(){}
	
	public PersonalCustomer(String firstName, String lastName, String address, double balance,String homePhone, String workPhone) {
		super(firstName, lastName, address, balance);
		this.homePhone = homePhone;
		this.workPhone = workPhone;
	}
	
	public double calculateInterest(){
		return (balance * 4.0 ) / 100;
	}
	
	public String getDetails(){
		return "Id" + id+"\n"+"Full Name : "+ getFullName()+"\n"+
		"Address : " + address+"\n"+"Balance : " + balance+"\n"+"Total Interest :" 
				+ calculateInterest()+"\n"+"Home Phone : " + homePhone +"\n"+
				"Work Phone : " + workPhone;
	}
	
	public String getHomePhone() {
		return homePhone;
	}
	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}
	public String getWorkPhone() {
		return workPhone;
	}
	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}
	
}
