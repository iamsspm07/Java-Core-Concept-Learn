public class Java_In_Class_Day02_7_ConsectiveArrayElements {

    public static int validatenputs(int[] arr, int target) {
        if(arr.length == 0){
            return -1;
        }
        if(target <= 0){
            return -3;
        }
        for(int i=0; i<=arr.length-1;i++){
            if(arr[i]<=0)
            return -2;
        }
        return 1;
    }

    public static boolean containConsectiveElements(int[] arr, int target) {
        if(validatenputs(arr, target)!=1)
        return false;
        for(int i=0; i<arr.length-1;i++){
            int sum =0;
            for(int j=1; j<=arr.length-1;j++){
                sum += arr[j];
                if(sum == target)
                    return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        int [] arr = {1,3,5,7,9};
        int target = 15; 
        System.out.println(containConsectiveElements(arr, target));
        System.out.println(validatenputs(arr, target));
    }
}
