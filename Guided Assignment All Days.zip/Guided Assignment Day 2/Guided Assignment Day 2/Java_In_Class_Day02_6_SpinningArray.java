//Assignment 

public class Java_In_Class_Day02_6_SpinningArray {
    public static int[] rotate(int[] arr, int nop) { 
        if(nop == 0){
            if(arr.length == 0){ 
                return null; 
            } 
            return arr;
        }
        int[] result = new int[arr.length]; 
        for(int i=0; i<arr.length; i++){
            int first = (i+nop) % arr.length; 
            result[first] = arr[i];
        } 
        return result;
}
public static void main(String[] args) {
    int arr[] = {1,2,3,4,5};
    int arr1[] = rotate(arr, 2);
    for (int i : arr1) {
        System.out.println(i + " ");   
    }
}
}