
public class Java_In_Class_Day01_6_CountLeftTruncatablePrime {
	public static int getCountOfLeftTruncatablePrime(int start_val, int end_val) {
        if (start_val > end_val)
            return -1;
        if (start_val < 0 || end_val < 0)
            return -2;
        if (start_val == 0 || end_val == 0)
            return -3;
        
        int count = 0;
        for (int i = start_val; i <= end_val; i++) {
        	if (isLeftTruncatablePrime(i))
        		count += 1;
        }
		return count;
	}
	
	public static boolean isLeftTruncatablePrime(int num) {
		while (isPrime(num) && num > 9) {
            if (("" + num).contains("0"))
                return false;
            num = Integer.parseInt(("" + num).substring(1));
        }
		if (isPrime(num)) {
            return true;
        }
		return false;
	}
	
	public static boolean isPrime(int num) {
		int c = 0;
        for (int i = 1; i <= num; i++) {
            if (num % i == 0) {
                c += 1;
            }
        }
        if (c == 2)
            return true;
		return false;
	}
	
	public static void main(String[] args) {
		System.out.println(getCountOfLeftTruncatablePrime(1,1000));
		System.out.println(isLeftTruncatablePrime(223));
	}
}
