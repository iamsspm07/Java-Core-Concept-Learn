//Guided_Assignment_No-1: 
public class Java_In_Class_Day01_7_RussianMultiplication {
	public static int getProduct(int num1, int num2) {
		if(num1 <0 || num2 <0) {
		return -1;
		}
		int res = 0;
		while(num2 > 0) {
			if ((num2 & 1)!=0) {
				res += num1;
			}
			num1 = num1 << 1;
			num2 = num2 >> 1;
		}
		return res;
	}
	public static void main(String[] args) {
		System.out.println(getProduct(-1,12));
		System.out.println(getProduct(11,12));
	}

}