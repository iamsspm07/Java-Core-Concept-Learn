package Guided_Assignment_Day_6_Q2;

public class TestingInterface {
	public static void main(String[] args) {
		MyCalculator myCalculator = new MyCalculator();
		System.out.println("The sum of divisor are:- "+ myCalculator.divisorSum(6));
	}
}
