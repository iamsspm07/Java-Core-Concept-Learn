package Guided_Assignment_Day_6_Q2;
interface AdvancedArithmetic {
	public abstract int divisorSum(int n);
}

class MyCalculator implements AdvancedArithmetic{

	@Override
	public int divisorSum(int n) {
		if(n <= 1) {
			return n;
		}
        int result = n + 1;
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
            	result += i;
            }
        }
		return result;
	}
}
