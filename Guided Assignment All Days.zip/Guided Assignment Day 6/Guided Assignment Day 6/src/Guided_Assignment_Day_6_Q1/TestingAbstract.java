package Guided_Assignment_Day_6_Q1;

public class TestingAbstract {
	public static void main(String[] args) {
		System.out.println("-------------------------------------------------------");
		Shape shapeRect = new Rectangel(30.3, 45.4);
		shapeRect.printDetails();
		System.out.println("-------------------------------------------------------");
		Shape shapeCir = new Circle(23.2);
		shapeCir.printDetails();
		System.out.println("-------------------------------------------------------");
		Shape shapeTri = new Triangle(146.2, 40.0);
		shapeTri.printDetails();
		System.out.println("-------------------------------------------------------");
	}

}
