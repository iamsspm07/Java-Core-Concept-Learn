package Guided_Assignment_Day_6_Q1;

abstract class Shape {
	abstract double getArea();
	abstract void printDetails();
}
class Rectangel extends Shape{
	double length;
	double breath;
	
	public Rectangel(double length, double breath) {
		super();
		this.length = length;
		this.breath = breath;
	}
	@Override
	double getArea() {
		
		return length*breath;
	}
	@Override
	void printDetails() {
		System.out.println("Type:- Rectangel");
		System.out.println("Length:- "+length);
		System.out.println("Breadth:- "+breath);
		System.out.println("Area:- "+length*breath);
	}
}
class Circle extends Shape{
	double radius;
	

	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	@Override
	double getArea() {
		return 3.14*radius*radius;
	}

	@Override
	void printDetails() {
		System.out.println("Type:- Circle");
		System.out.println("Radius:- "+radius);
		System.out.println("Area:- "+ 3.14*radius*radius);
		
	}
}
class Triangle extends Shape{
	double base;
	double height;
	
	public Triangle(double base, double height) {
		super();
		this.base = base;
		this.height = height;
	}

	@Override
	double getArea() {
		return 0.5*base*height;
	}

	@Override
	void printDetails() {
		System.out.println("Type:- Triangle");
		System.out.println("Base:- "+base);
		System.out.println("Height:- "+height);
		System.out.println("Area:- "+0.5*base*height);
	}
	
}