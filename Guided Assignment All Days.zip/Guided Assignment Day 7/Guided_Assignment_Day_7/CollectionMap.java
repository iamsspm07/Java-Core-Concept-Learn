package Guided_Assignment_Day_7;

import java.util.*;

public class CollectionMap {
	
	Map<Integer, Employee> empMap = new HashMap<>();
	
	public CollectionMap() {}
	
	
	public CollectionMap(Map<Integer, Employee> empMap) {
		super();
		this.empMap = empMap;
	}
	
	public Map<Integer, Employee> getEmployeeMap() {
		return empMap;
	}


	public void setEmployeeMap(Map<Integer, Employee> empMap) {
		this.empMap = empMap;
	}

	public int addEmployee(Employee employee) {
		int id = employee.getId();
		
		if(!empMap.containsKey(id)) {
			empMap.put(id,employee);
			return 0;
			
		}else if(empMap.containsValue(employee))
			return 2;
		else
			return 1;
	}
	
	public int removeEmployee(int employeId) {
		if(empMap.containsKey(employeId)) {
			empMap.remove(employeId);
			return 0;
		}else
			return 2;
		
	}
	
	public Employee findEmployee(int employeId) {
		if(empMap.containsKey(employeId)) {
			return (Employee) empMap.get(employeId);
		}else
			return null;
	}
	
	public Collection<Employee> getEmployeeList() {
		if(!empMap.isEmpty()) {
			return empMap.values();
		}
		return null;
	}

}
