package Guided_Assignment_Day_7;

public class TestEmployee {
	public static void main(String[] args) {
		
		Employee employee1 = new Employee(1,"Sujit Shibaprasad Maity",500000);
		Employee employee2 = new Employee(2,"Kartik",1000000);
		Employee employee3 = new Employee(3,"Saurabh",100000);
		Employee employee4 = new Employee(4,"Bhargavi",10000);
		Employee employee5 = new Employee(5,"Sai Dhama",100000);
		Employee employee6 = new Employee(6,"Naga Abhiskek",10000);

		CollectionMap collectionMap = new CollectionMap();
		
		System.out.println("----------------------------------------------------");
		System.out.println("Adding the Employee into the Collection Map");
		collectionMap.addEmployee(employee1);
		collectionMap.addEmployee(employee2);
		collectionMap.addEmployee(employee3);
		collectionMap.addEmployee(employee4);
		collectionMap.addEmployee(employee5);
		collectionMap.addEmployee(employee6);
		
		System.out.println("----------------------------------------------------");
		System.out.println("Remove Employee by Using Employee Id");
		collectionMap.removeEmployee(5);
		System.out.println(collectionMap.getEmployeeList());
		
		
		System.out.println("----------------------------------------------------");
		System.out.println("Find Employee by Using Employee Id");
		System.out.println(collectionMap.findEmployee(1));
		
		System.out.println("----------------------------------------------------");
		System.out.println("Get all the Employees Details");
		System.out.println(collectionMap.getEmployeeList());
		for(Object employees: collectionMap.getEmployeeList())
			System.out.println(employees);

	}
}
