public class LuckyNumber {
    public static int convertMMMtoMM(String str) {
		
		str = str.substring(0, 3).toLowerCase();
		String[] month = {"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"};
		for(int i=0; i<month.length; i++) {
			if(str.equals(month[i])) {
				return i+1;
			}
		}
		return 0;
	}
	public static int getSumOfDigits(int n) {
		int digit, sum = 0;
		while(n > 0)  
		{  
		digit = n % 10;  
		sum = sum + digit;   
		n = n / 10;  
		}  
		return sum;
	}
	public static int getLuckyNumber(String str){

		String s1[] = str.split("-");
		int n1 = getSumOfDigits(Integer.parseInt(s1[0]));
		int n2 = getSumOfDigits(convertMMMtoMM(s1[1]));
		int n3 = getSumOfDigits(Integer.parseInt(s1[2]));
		int sum = n1+n2+n3;
		while(sum > 9) {
			sum = getSumOfDigits(sum);
		}
		return sum;
	}
	public static void main(String[] args) {
		System.out.println(getLuckyNumber("15-NOV-2016"));
		
	}

}

