public class Java_In_Class_Day03_6_StringsWithPattern {

    public static String[] getWordsContainsPattern(String[] str,String pattern) {
		int count = 0;
		for(String s: str) {
			if(s.contains(pattern)) {
				count++;
			}
		}
		String[] result = new String[count];
		int i=0;
		for(String s: str) {
			String newStr =s.toUpperCase();
			if(newStr.contains(pattern.toUpperCase())) {
				result[i] = newStr;
				i++;
				
			}
		}
		return result;
	}
	public static void main(String[] args) {
		String[] words = {"South Africa", "Afghanistan", "Sri Lanka", "New Zealand", "West Indies", "England", "India", "Australia", "Pakistan", "Bangladesh"};
		String[] temp = getWordsContainsPattern(words, "an");
		if (null != temp) {
			 for (String word : temp) {
				 System.out.println(word);
			 }
		} else{
			 System.out.println("null");
		}


	}

}
