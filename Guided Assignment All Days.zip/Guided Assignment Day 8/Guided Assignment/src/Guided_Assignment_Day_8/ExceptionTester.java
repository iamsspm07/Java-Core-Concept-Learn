package Guided_Assignment_Day_8;

public class ExceptionTester {

	public static void main(String[] args) {
		
		Account account1 = new Account(123,5125452);
		Account account2 = new Account(234,6265226);
		Account account3 = new Account(345,66582);
		Account account4 = new Account(567,125458);
		
		AccountManager am = new AccountManager();
		
		am.addAccount(account1);
		am.addAccount(account2);
		am.addAccount(account3);
		am.addAccount(account4);

		
		try {
			double newBalance = am.deposit(567, 10);
			System.out.println("AFTER DEPOSITED BALANCE: "+newBalance);
		} catch (InvalidAccountException | NegativeAmountException e) {
			
			e.printStackTrace();
		} 
		
		
		
	}

}
