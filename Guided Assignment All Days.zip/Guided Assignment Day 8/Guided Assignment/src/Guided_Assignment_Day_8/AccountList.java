package Guided_Assignment_Day_8;

import java.util.*;

public class AccountList {
	protected List<Account> list = new ArrayList<>();

	public List<Account> getValidAccount() {
		return list;
	}

	public void setValidAccount(List<Account> validAccount) {
		this.list = validAccount;
	}
}


class InsufficientFundsException extends Exception{
	
	InsufficientFundsException(String msg){
		super(msg);
	}
}

class NegativeAmountException extends Exception{
	NegativeAmountException(String msg){
		super(msg);	
	}
}

class InvalidAccountException extends Exception{
	InvalidAccountException(String msg){
		super(msg);
	}
}
