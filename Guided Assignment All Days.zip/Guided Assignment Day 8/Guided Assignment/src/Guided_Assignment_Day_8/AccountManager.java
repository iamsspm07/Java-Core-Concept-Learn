package Guided_Assignment_Day_8;

public class AccountManager extends AccountList{
	
	public boolean checkAccount(int accountNum) {
		for(Account obj:list) {
			if(accountNum == obj.getAccountNumber())
				return true;
		}
		return false;
	}
	
	public Account getAccount(int acc) {
		for(Account obj:list) {
			if(obj.getAccountNumber() == acc)
				return obj;
		}
				return null;
	}
	
	public double deposit(int accountNo, double amount) throws InvalidAccountException, NegativeAmountException {
		if(checkAccount(accountNo)) {
			if(amount>0) {
				Account ac = getAccount(accountNo);
				ac.setBalance(ac.getBalance()+amount);
				return ac.getBalance();
			}else {
				throw new NegativeAmountException("Amount is not in negative");
			}
		}else {
			throw new InvalidAccountException("Invalid Account number");
		}
	}
	
	public double withdraw(int accountNo, double amount) throws InsufficientFundsException, NegativeAmountException, InvalidAccountException {
		Account getAcc;
		if(checkAccount(accountNo)) {
			getAcc = list.get(new Integer(accountNo));
			if(amount>0) {
				if(getAcc.getBalance()>=amount) {
					getAcc.setBalance(getAcc.getBalance()-amount);
					return getAcc.getBalance();
				}else {
					throw new InsufficientFundsException("Insufficient Funds");
				}
			}else {
				throw new NegativeAmountException("Amount is not in negative");
			}
		}else {
			throw new InvalidAccountException("Invalid Account number");
		}
	}

	
	public void addAccount(Account obj) {
		list.add(obj);
	}
	
	public void getAllAccount() {
		for(Account obj:list)
			System.out.println(obj.toString());
	}
}


