package Guided_Assignment_Day_5_Q1;

public class FullTimeEmployee extends Employee{
	protected double base;
	protected double bonus;
	
	public FullTimeEmployee() {
		super();
	}

	public FullTimeEmployee(double base, double bonus,int id, String firstName, String lastName, String address) {
		super(id, firstName, lastName, address);
		this.base = base;
		this.bonus = bonus;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	@Override
	public String toString() {
		return "FullTimeEmployee [base=" + base + ", bonus=" + bonus + ", id=" + id + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", address=" + address + "]";
	}
	
	public void computeSal(int id, String firstName, String lastName, String address,double base, double bonus) {
		System.out.println("Employee Id:- "+id);
		System.out.println("Employee First Name:- "+firstName);
		System.out.println("Employee Last Name:- "+lastName);
		System.out.println("Employee Address:- "+address);
		System.out.println("Employee Base Salary:- " + base);
		System.out.println("Employee Bonous:- " + bonus);
		double total = base + bonus;
		System.out.println("Full Time Salary:- "+total);
	}
}
	
	

