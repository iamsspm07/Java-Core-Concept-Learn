package Guided_Assignment_Day_5_Q1;

public class EmployeeDetails {
	public void showDetails() {
		System.out.println("---------------------------------------------------------------");
		System.out.println("Part Time Employee:-");
		PartTimeEmployee part = new PartTimeEmployee();
		part.computeSal(101, "Sujit Shibaprasad", "Maity", "Mumbai, Maharashtra", 48, 100);
		System.out.println("---------------------------------------------------------------");
		System.out.println("Full Time Employee:-");
		FullTimeEmployee full = new FullTimeEmployee();
		full.computeSal(101, "Sujit Shibaprasad", "Maity", "Mumbai, Maharashtra", 46000, 10000);
		System.out.println("---------------------------------------------------------------");
	}
	public static void main(String[] args) {
		EmployeeDetails empd = new EmployeeDetails();
		empd.showDetails();
	}
}