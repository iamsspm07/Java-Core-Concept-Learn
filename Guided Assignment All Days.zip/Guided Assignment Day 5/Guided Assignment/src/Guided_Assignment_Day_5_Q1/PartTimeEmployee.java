package Guided_Assignment_Day_5_Q1;

public class PartTimeEmployee extends Employee{
	protected double hoursWorked;
	protected double amountPerHour;
	
	public double getHoursWorked() {
		return hoursWorked;
	}
	public void setHoursWorked(double hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	public double getAmountPerHour() {
		return amountPerHour;
	}
	public void setAmountPerHour(double amountPerHour) {
		this.amountPerHour = amountPerHour;
	}
	public PartTimeEmployee(double hoursWorked, double amountPerHour,int id, String firstName, String lastName, String address) {
		super(id, firstName, lastName, address);
		this.hoursWorked = hoursWorked;
		this.amountPerHour = amountPerHour;
	}
	public PartTimeEmployee() {
		super();
	}
	@Override
	public String toString() {
		return "PartTimeEmployee [hoursWorked=" + hoursWorked + ", amountPerHour=" + amountPerHour + ", id=" + id
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + "]";
	}
	public void computeSal(int id, String firstName, String lastName, String address,double hoursWorked, double amountPerHour) {
		System.out.println("Employee Id:- "+id);
		System.out.println("Employee First Name:- "+firstName);
		System.out.println("Employee Last Name:- "+lastName);
		System.out.println("Employee Address:- "+address);
		System.out.println("Employee Working Hours:- " + hoursWorked);
		System.out.println("Employee Amount Per Hours:- " + amountPerHour);
		double total = hoursWorked * amountPerHour;
		System.out.println("Part Time Salary:- "+total);
	}
}
