public class TalentSprint {
	private double basePay;
	private int hoursWorked;
	
	public TalentSprint() {
		super();
	}
	
	public TalentSprint(double basePay, int hoursWorked) {
		super();
		this.basePay = basePay;
		this.hoursWorked = hoursWorked;
	}

	@Override
	public String toString() {
		return "TalentSprint [basePay=" + basePay + ", hoursWorked=" + hoursWorked + "]";
	}

	public double getBasePay() {
		return basePay;
	}

	public void setBasePay(double basePay) {
		this.basePay = basePay;
	}

	public int getHoursWorked() {
		return hoursWorked;
	}

	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	public void computeSalary() {
		if(hoursWorked >=60 || basePay <=8)
		{
			System.out.println("error");
		}
		else if (hoursWorked<= 40)
		{
			System.out.println(40*basePay);
		}
		else 
		{
			System.out.println((40*basePay)+((hoursWorked-40)*basePay*1.5));
		}
	}
	public static void main(String[] args) {
		TalentSprint talentSprint1 = new TalentSprint(7.50,35);
		TalentSprint talentSprint2 = new TalentSprint(8.20,47);
		TalentSprint talentSprint3 = new TalentSprint(10.00,3);
		TalentSprint talentSprint4 = new TalentSprint(7.5,35);
		
		talentSprint1.computeSalary();
		talentSprint2.computeSalary();
		talentSprint3.computeSalary();
		talentSprint4.computeSalary();
		
	}
}

