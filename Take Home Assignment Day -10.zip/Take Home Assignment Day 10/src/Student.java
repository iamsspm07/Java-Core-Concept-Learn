public class Student {
	private String name;
	private int id;
	private int[] marks =new int[3];

	public Student(int id, String name, int marks1, int marks2, int marks3) {
		super();
		this.name = name;
		this.id = id;
		marks[0] = marks1;
		marks[1] = marks2;
		marks[2] = marks3;
	}
	
	public int getTotalMarks() {
		return (marks[0] + marks[1] + marks[2]);
	}

	@Override
	public String toString() { 
		return "Student [Name: " + name + ", Id: " + id + ", Mark1: " + marks[0] + ", Mark2: " + marks[1] + ", Mark3: " + marks[2] +", TotalMarks= " + getTotalMarks()+ "]";
	}
}
