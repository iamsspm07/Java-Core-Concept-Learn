import java.io.*;
import java.util.*;

public class TestStudent {

	public static void main(String[] args)  {
		DataFile df = new DataFile();
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile("D:\\inputFile.txt","r");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		List<Student> studentList = df.readStudents(raf);
		for(Student student: studentList) {
			System.out.println(student);
		}
	}

}
