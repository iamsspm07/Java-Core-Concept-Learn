import java.io.*;
import java.util.*;


public class DataFile {
	public List<Student> readStudents(RandomAccessFile raf){
		List<Student> studentList = new ArrayList<>();
		try {
			String line;
			while((line = raf.readLine())!=null){
	
				String[] str = line.split(":");
				Student student = new Student(Integer.parseInt(str[0]), str[1], Integer.parseInt(str[2]), Integer.parseInt(str[3]), Integer.parseInt(str[4]));
				studentList.add(student);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				raf.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return studentList;
		
		}
	

}
