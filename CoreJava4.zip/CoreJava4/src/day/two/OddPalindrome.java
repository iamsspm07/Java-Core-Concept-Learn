package day.two;

public class OddPalindrome {

	public static int getReverse(int num){
		int rev = 0;
		while(num > 0){
			rev = (rev * 10) + (num % 10);
			num = num / 10;
		}
		return rev;
	}
	
	public static boolean isPalindrome(int num){
		return getReverse(num) == num; //true or false
	}
	
	public static String oddPalindromes(int start, int end){
		String str="";
		for(int i = start; i <= end; i++){
			if(isPalindrome(i) && i % 2 != 0){
				str += i+",";
			}
		}
		return str.substring(0,str.length()-1);
	}
	public static void main(String[] args) {
		System.out.println(oddPalindromes(100,200));
	}

}
