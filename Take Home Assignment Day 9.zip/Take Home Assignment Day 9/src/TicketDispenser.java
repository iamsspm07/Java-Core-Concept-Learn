public class TicketDispenser {
	int allotedSeats = 100;
	static int counter = 1;
	public synchronized String allotSeatNumber(int noOfSeats) {
		String space = "";
		while(noOfSeats > 0) {
			if(counter <= allotedSeats) {
				space += counter + ",";
				counter++;
				noOfSeats--;
			}
		}
		return space.substring(0,space.length()-1);
	}
}
