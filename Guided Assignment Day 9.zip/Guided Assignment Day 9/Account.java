public class Account {
	int balance = 5000;
	
	public synchronized void deposit(int amount) {
		String name = Thread.currentThread().getName();
	
		System.out.println(name +" After Deposit "+ (balance + amount));
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		balance += amount;
	}
	
	public synchronized void withdraw(int amount) {
		String name = Thread.currentThread().getName();
		System.out.println(name+ " After Withdraw "+(balance-amount));
        try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        balance -= amount;
	}
}