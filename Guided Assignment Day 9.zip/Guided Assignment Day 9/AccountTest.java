public class AccountTest {
    public static void main(String[] args) {
        Account account = new Account();
        Thread thread1 = new Thread(){
            public void run(){
                account.deposit(1000);
                account.withdraw(500);

            }
        };
        thread1.setName("Sujit S Maity");
        thread1.start();

        Thread thread2 = new Thread(){
            public void run(){
                account.deposit(1000);
                account.withdraw(500);

            }
        };
        thread2.setName("Shibaprasad Maity");
        thread2.start();
    }
}
