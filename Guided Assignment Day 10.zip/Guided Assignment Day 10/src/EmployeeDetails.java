import java.io.*;
import java.util.*;

public class EmployeeDetails {

	List<Employee> employeeList = new ArrayList<Employee>();

	public List<Employee> getList() {
		return employeeList;
	}

	public void setList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}
	
	
	public void readEmployeeDetails(String filename) throws FileReadException {
		FileReader fr = null;
		BufferedReader br = null;	
		
		try {
			fr = new FileReader(filename);
			br = new BufferedReader(fr);
			String line;
			while((line = br.readLine())!=null){
				System.out.println(line);
			}

		} catch (FileNotFoundException e) {
			throw new FileReadException();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void writeEmployeeDetails(String filename) {
		FileWriter fw = null;
		try {
			 fw = new FileWriter(filename);
			 for(Employee obj:employeeList) {
				 fw.write(obj.getEmpId()+";"+obj.getEmpName()+";"+obj.getEmpDesignation()+";"+obj.getEmpSalary()+"\n");
			 }
			 
			 
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void addEmployee(Employee obj) {
		employeeList.add(obj);
	}

}
class FileReadException extends Exception{
	public String toString(){
		return "FileReadException";
	}

}

