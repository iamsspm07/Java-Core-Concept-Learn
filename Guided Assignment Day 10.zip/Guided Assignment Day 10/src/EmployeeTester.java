public class EmployeeTester {

	public static void main(String[] args) {
		
		EmployeeDetails employeeDetails = new EmployeeDetails();
		
		Employee employee1 = new Employee(1001,"Ramesh","Assistant Engineer",15000);
		Employee employee2 = new Employee(1002,"David","Sr.Assistant Engineer",25000);
		Employee employee3 = new Employee(1003,"Rahim","Engineer",20000);
		
		employeeDetails.addEmployee(employee1);
		employeeDetails.addEmployee(employee2);
		employeeDetails.addEmployee(employee3);
		
		String filePath = "D://EmployeeData.txt";
        
		employeeDetails.writeEmployeeDetails(filePath);

		try {
			employeeDetails.readEmployeeDetails(filePath);
		} catch (FileReadException e) {
			e.printStackTrace();
		}
	}

}

