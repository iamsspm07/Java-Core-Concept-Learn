package day.five;

import java.util.Scanner;

public class CustomerDemo2 {

	public static void main(String[] args) {
		Bank bank = new Bank();
		int choice;
		
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1. Add Personal Customer ");
			System.out.println("2. Add Commercial Customer ");
			System.out.println("3. Display Customers");
			System.out.println("4. Display Customer By ID");
			System.out.println("5. Deposit Amount ");
			System.out.println("6. Withdraw "); 
			System.out.println("7. Transfer "); //id, amount to be read then check after withdraw amount >=1000
			System.out.println("8. E X I T");
			
			System.out.println("Enter your choice : ");
			choice = sc.nextInt();
			
			switch(choice){
			
			case 1:
				System.out.println("Enter Personal Customer Details...");
				System.out.println("Enter first name : ");
				String firstName = sc.next();
				System.out.println("Enter last name : ");
				String lastName = sc.next();
				System.out.println("Enter address : ");
				String address = sc.next();
				System.out.println("Enter amount : ");
				double amount = sc.nextDouble();
				System.out.println("Enter home phone : ");
				String homePhone = sc.next();
				System.out.println("Enter work phone : ");
				String workPhone = sc.next();
				
				int id = bank.addPersonalCustomer(firstName, lastName, address, amount,homePhone,workPhone);
				System.out.println("Personal Customer Registered successfully .. id is "+id);
			break;	
			
			case 2:
				System.out.println("Enter Commercial Customer Details...");
				System.out.println("Enter first name : ");
				firstName = sc.next();
				System.out.println("Enter last name : ");
				lastName = sc.next();
				System.out.println("Enter address : ");
				address = sc.next();
				System.out.println("Enter amount : ");
				amount = sc.nextDouble();
				System.out.println("Enter contact person name : ");
				String contactPersonName = sc.next();
				System.out.println("Enter contactPersonPhone : ");
				String contactPersonPhone = sc.next();

				id = bank.addCommercialCustomer(firstName, lastName, address, amount,contactPersonName,contactPersonPhone);
				System.out.println("Commercial Customer Registered successfully .. id is "+id);
			break;	
			
			case 3: 
				Customer personalOrCommercial[] = bank.getAllCustomers();  
				for(Customer customer : personalOrCommercial){
					if(customer!=null)
					System.out.println(customer);//toString()
				}
				break;
			
			case 4: 
				System.out.println("Enter id to display : ");
				id = sc.nextInt();
				Customer customer = bank.getCustomerById(id);
				System.out.println(customer);
				break;
				
			case 5: 
				System.out.println("Enter id to deposit :");
				id = sc.nextInt();
				System.out.println("Enter amount to deposit : ");
				amount = sc.nextDouble();
				String result = bank.deposit(id, amount);
				System.out.println(result);
				break;
				
			case 6:
				System.out.println("Enter id to withdraw :");
				id = sc.nextInt();
				System.out.println("Enter amount to withdraw : ");
				amount = sc.nextDouble();
				result = bank.withdraw(id, amount);
				System.out.println(result);
				break;
				
			case 7:
				System.out.println("Enter from id :");
				int fromId = sc.nextInt();
				System.out.println("Enter to id :");
				int toId = sc.nextInt();
				System.out.println("Enter amount to withdraw : ");
				amount = sc.nextDouble();
				result = bank.transfers(fromId, toId, amount);
				System.out.println(result);
				break;
			}
		
		}while(choice < 8);

	}
}

