package day.five;

//super class
class Parent{ 
	protected int a,b;//gives access to only childs in same package or out side the package
	
	public Parent(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}
	public Parent(){
		System.out.println("Hi! This is a parent constructor...");
	}
	public void showParent(){
		System.out.println("Hi! This is parent show..");
	}
}

class Child extends Parent{ //Inheritance
	private int c;
	
	public Child(int a, int b, int c) {
		super(a, b);
		this.c = c;
	}
	public Child(){
		super();//invokes parent class constructor
		System.out.println("Hi! This is a child constructor...");
	}
	public void showChild(){
		System.out.println("Hi! This is child show..");
	}
	public void sum(){
		System.out.println("The sum is : "+(a + b + c));
	}
}

public class InheritanceDemo1 {

	public static void main(String[] args) {
		Child child = new Child();
		child.showParent();
		child.showChild();
		
		Child child2 = new Child(10,20,30);
		child2.sum();
	}
}
