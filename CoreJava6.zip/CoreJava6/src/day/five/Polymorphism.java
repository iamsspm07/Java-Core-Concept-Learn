package day.five;


/*
1. compile time:- (at the time of manufacturing) -> Coffee Machine
   method overloading:- writing multiple methods in a class with same name but difference
   						in parameters.


2. runtime poly: (after manufacture or at usage time) -> Mobile 
	method overriding:- write a method inside the parent and redefining inside child with 
					    same name and same parameters.
*/

class Maths{
	public void add(int a,int b){
		System.out.println("The addition is : " + (a + b));
	}
	public void add(double a,double b){
		System.out.println("The addition is : " + (a + b));
	}
	public void add(int a,int b, int c){
		System.out.println("The addition is : " + (a + b + c));
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		Maths maths = new Maths();
		maths.add(10, 20);
		maths.add(1.5, 2.5);
		maths.add(10, 20,30);
	}
}
