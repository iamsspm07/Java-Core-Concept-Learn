package day.two;

import java.util.Scanner;

public class ArrayDemo1 {

	public static void main(String[] args) {
		
		int a[] = new int[8]; //single dimensional array
		Scanner sc = new Scanner(System.in);
	
		
		System.out.println("Enter 5 numbers : ");
		for(int i=0; i<a.length; i++)
		a[i] = sc.nextInt();
		
		
		for(int i=0; i<a.length; i++)
		System.out.println(a[i]);
		
		
	}

}
