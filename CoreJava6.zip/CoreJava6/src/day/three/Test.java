package day.three;

public class Test {

	public static void main(String[] args) {
		String str1=new String("PASHA");
		String str2=new String("PASHA");
		
		System.out.println(str1.equalsIgnoreCase(str2));

	}

}
