package Take_Home_Assignment_Day_5;

public class Soccer extends Sports{
    @Override
    String getName(){
    	return "In Soccer,";
    }

    @Override
	public void getNumberOfTeamMembers () {
       System.out.println( getName()+ " each team has 11 players");
}

}
