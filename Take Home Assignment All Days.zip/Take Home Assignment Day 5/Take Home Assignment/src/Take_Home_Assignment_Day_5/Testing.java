package Take_Home_Assignment_Day_5;

public class Testing {
	public static void main(String []args){
		System.out.println("--------------------------------------------");
		System.out.println("Sports Class:-");
		Sports sports = new Sports();
		sports.getNumberOfTeamMembers();
		System.out.println("--------------------------------------------");
		System.out.println("Soccer Class:-");
		Soccer soccer = new Soccer();
		soccer.getNumberOfTeamMembers();
	}
}
