package Take_Home_Assignment_Day_5;

public class Sports{
	
    String getName(){
        return "Sports";
    }

    public void getNumberOfTeamMembers(){
        System.out.println( "Each team has n players in " + getName() );
    }
}


