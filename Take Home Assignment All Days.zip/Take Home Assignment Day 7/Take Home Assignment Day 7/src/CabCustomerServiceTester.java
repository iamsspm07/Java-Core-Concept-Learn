
public class CabCustomerServiceTester {
	public static void main(String[] args) {
		CabCustomer cabcustomer1 = new CabCustomer(101 , "Sujit Shibaprasad Maity" , "Andheri" , "Goregaon" , 35, 917770053550l);
		CabCustomer cabcustomer2 = new CabCustomer(102 , "Saurabh" , "Nagpur" , "Mumbai" , 1200, 918369587594l);
		CabCustomer cabcustomer3 = new CabCustomer(103 , "Kartik" , "Delhi" , "Mumbai" , 1024, 918369587594l);
		CabCustomer cabcustomer4 = new CabCustomer(104 , "Bhargavi" , "Hyd" , "Chennai" , 1500, 9177558585585l);
		CabCustomer cabcustomer5 = new CabCustomer(105 , "Abhishek" , "Hyd" , "Chennai" , 1500, 917755858555l);
		CabCustomer cabcustomer6 = new CabCustomer(106 , "Sai Dhama" , "Hyd" , "Chennai" , 1500, 91558585585l);
		
		CabCustomerService cabcustomerservice = new CabCustomerService();
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("NewCustomer = "+cabcustomerservice.isNewCustomer(cabcustomer1));
		cabcustomerservice.addCabCustomer(cabcustomer1);
		cabcustomerservice.addCabCustomer(cabcustomer2);
		cabcustomerservice.addCabCustomer(cabcustomer3);
		cabcustomerservice.addCabCustomer(cabcustomer4);
		cabcustomerservice.addCabCustomer(cabcustomer5);
		cabcustomerservice.addCabCustomer(cabcustomer6);
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("NewCustomer = "+cabcustomerservice.isNewCustomer(cabcustomer1));
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("Bill Generated = " +cabcustomerservice.calculateBill(cabcustomer1));
		System.out.println("Bill Bill Amount to Pay = "+cabcustomerservice.printBill(cabcustomer1));
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("Bill Generated = " +cabcustomerservice.calculateBill(cabcustomer2));
		System.out.println("Bill Bill Amount to Pay = "+cabcustomerservice.printBill(cabcustomer2));
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("Bill Generated = " +cabcustomerservice.calculateBill(cabcustomer3));
		System.out.println("Bill Bill Amount to Pay = "+cabcustomerservice.printBill(cabcustomer3));
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("Bill Generated = " +cabcustomerservice.calculateBill(cabcustomer4));
		System.out.println("Bill Bill Amount to Pay = "+cabcustomerservice.printBill(cabcustomer4));
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("Bill Generated = " +cabcustomerservice.calculateBill(cabcustomer5));
		System.out.println("Bill Bill Amount to Pay = "+cabcustomerservice.printBill(cabcustomer5));
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("Bill Generated = " +cabcustomerservice.calculateBill(cabcustomer6));
		System.out.println("Bill Amount to Pay = "+cabcustomerservice.printBill(cabcustomer6));
		System.out.println("------------------------------------------------------------------------------");
	}

}
