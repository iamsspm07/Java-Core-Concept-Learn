import java.util.*;

public class CabCustomerService {
private List<CabCustomer> list = new ArrayList<CabCustomer>();
	
	public void addCabCustomer(CabCustomer cabcus) {
		list.add(cabcus);
	}
	
	public boolean isNewCustomer(CabCustomer cabcus) {
		for(int i =0;i<list.size();i++)
		{
	      long value = list.get(i).getPhone() ;
	      if(value == cabcus.getPhone()) {
	    	  return false;
	      }
		}
		return true;
	}
	
	public double calculateBill(CabCustomer cabcus) {
		double fair = 0.00;
	    if(!isNewCustomer(cabcus)){
			fair += fair;
	    }
		if(cabcus.getDistance() <= 4){
			 fair += 80.00;
		}
		if(cabcus.getDistance() > 4){
		    fair += ((cabcus.getDistance() - 4)*6 + 80);
		}
		return fair;
	}
	
	public String printBill(CabCustomer cabcus) {
		double value = calculateBill(cabcus);
		
		return cabcus.getCustomerName().toUpperCase() +" please pay your bill of Rs."+value;
	
	}
	
}
