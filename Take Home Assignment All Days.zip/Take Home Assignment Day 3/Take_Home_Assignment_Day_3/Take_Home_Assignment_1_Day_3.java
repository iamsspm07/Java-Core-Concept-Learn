public class Take_Home_Assignment_1_Day_3 {
    public static void main(String[] args) {
		System.out.println(reverse("Sujit Shibaprasad Maity"));
        System.out.println(reverse("sujit maity"));
        System.out.println(reverse(null));
        System.out.println(reverse("SUJIT"));
        System.out.println(reverse(""));
	}
	
	public static String reverse(String name) {
        char ch;
		String result="";
		if((name == null) || (name.length() == 0)){
			return null;
		}
		else {
			String[] arr = name.split(" ");
			for (int j=0;j<arr.length;j++)
			{
			String revers = "";
			 for (int i=0; i<arr[j].length(); i++)
		      {
		        ch= arr[j].charAt(i); 
		        revers= ch+revers; 
		      }
			 result +=revers+" ";
			}
			return result;
		}
    }
}