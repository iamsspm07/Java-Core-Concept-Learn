import java.util.regex.*;

public class Take_Home_Assignment_2_Day_3 {

    public static void main(String[] args) {
        System.out.println(checkString("abcd"));
        System.out.println(checkString("ABCD"));
        System.out.println(checkString("AbCdE"));
        System.out.println(checkString("aabbcc"));
        System.out.println(isValidString("sujit"));
        System.out.println("----------------------------------------------------------");
        System.out.println(checkString("aabbcca"));
        System.out.println(checkString("abc@!"));
        System.out.println(checkString("ABCD12"));
        System.out.println(checkString("a_b_c"));
        System.out.println(isValidString(null));
        System.out.println(checkString("sujit12"));
        System.out.println("----------------------------------------------------------");
        System.out.println(checkString("AbCdE"));
        System.out.println(isValidString("sujit"));
        System.out.println(isPositiveString("aabbcc"));

    }

    public static boolean isValidString(String name) {
        String alphabet = "^[A-Za-z]\\w{1,29}$";
        Pattern p = Pattern.compile(alphabet);
        if(name == null){
            return false;
        }
        Matcher m = p.matcher(name);
        return m.matches();
}
    public static boolean isPositiveString(String name) {
        for(int i = 0;i<name.length()-1;i++)         
        if(name.charAt(i) > name.charAt(i+1))
            return false; 
        return true;
    }

    public static boolean checkString(String name) {
        if (isPositiveString(name.toLowerCase())){
            return true;
        }
        return false;
    }
}