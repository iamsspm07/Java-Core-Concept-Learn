package Take_Home_Assignment_Day_6;

abstract class Book {
	protected String title;
	abstract String getTitle();
	abstract void setTitle(String title);
}

class MyBook extends Book{

	@Override
	String getTitle() {
		return title;
	}

	@Override
	void setTitle(String title) {
		this.title = title;
	}
}
