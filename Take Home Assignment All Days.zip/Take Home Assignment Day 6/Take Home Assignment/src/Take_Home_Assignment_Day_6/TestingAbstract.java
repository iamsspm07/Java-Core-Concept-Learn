package Take_Home_Assignment_Day_6;

public class TestingAbstract {
	public static void main(String[] args) {
		Book book = new MyBook();
		book.setTitle("A tale of two cities");
		System.out.println("The Title of My Book Is: "+book.getTitle());
	}
}
