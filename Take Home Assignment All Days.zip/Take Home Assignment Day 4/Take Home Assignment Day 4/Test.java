
public class Test {
	public static void main(String[] args) {
		System.out.println("--------------------------------------------");
		Bowler b = new Bowler("Sujit",10,5,750,463);
		b.computeBowlingAverage();
		System.out.println("--------------------------------------------");
		Bowler b1 = new Bowler("Sujit",10,5,750,463);
		b1.showStatistics();
		System.out.println("--------------------------------------------");
		Bowler b2 = new Bowler("Sujit",10,5,750,463);
		b2.computeStrikeRate();
		System.out.println("--------------------------------------------");
	}
}
