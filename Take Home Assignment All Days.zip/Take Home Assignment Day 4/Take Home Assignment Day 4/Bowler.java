public class Bowler {
	String name;
	int wickets;
	int matches;
	int balls_bowled;
	int runs_conceded;

	public Bowler(String name, int wickets, int matches, int balls_bowled, int runs_conceded) {
		super();
		this.name = name;
		this.wickets = wickets;
		this.matches = matches;
		this.balls_bowled = balls_bowled;
		this.runs_conceded = runs_conceded;
	}

	public Bowler() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getWickets() {
		return wickets;
	}

	public void setWickets(int wickets) {
		this.wickets = wickets;
	}

	public int getMatches() {
		return matches;
	}

	public void setMatches(int matches) {
		this.matches = matches;
	}

	public int getBalls_bowled() {
		return balls_bowled;
	}

	public void setBalls_bowled(int balls_bowled) {
		this.balls_bowled = balls_bowled;
	}

	public int getRuns_conceded() {
		return runs_conceded;
	}

	public void setRuns_conceded(int runs_conceded) {
		this.runs_conceded = runs_conceded;
	}

	@Override
	public String toString() {
		return "Bowler [name=" + name + ", wickets=" + wickets + ", matches=" + matches + ", balls_bowled="
				+ balls_bowled + ", runs_conceded=" + runs_conceded + "]";
	}

	public void computeBowlingAverage() {
		if((wickets < 0)||(matches < 0)||(balls_bowled < 0)||(runs_conceded < 0)) {
			System.out.println("Error");
		}
		else if(matches == 0 && (runs_conceded > 0 || balls_bowled > 0)) {
			System.out.println("Error");
		}
		else {
			if(runs_conceded==0 || wickets==0) {
				System.out.println("Error");
			}
			else {
				System.out.println("Name:- "+getName());
				double bowlingAverage = (double) runs_conceded/wickets;
				System.out.println("bowling_avg:- " +bowlingAverage);
			}		
		}
	}

	public void showStatistics() {
		if((wickets < 0)||(matches < 0)||(balls_bowled < 0)||(runs_conceded < 0)) {
			System.out.println("Error");
		}
		else if(matches == 0 && (runs_conceded > 0 || balls_bowled > 0)) {
			System.out.println("Error");
		}
		else {
			if(runs_conceded==0 || wickets==0) {
				System.out.println("Error");
			}
			else {
				System.out.println("Name:- "+getName());
				System.out.println("Wickets:- "+getWickets());
				System.out.println("Matches:- "+getMatches());
				System.out.println("Balls_bowled:- "+getBalls_bowled());
				System.out.println("Runs_conceded:- "+getRuns_conceded());
			}
		}
	}
	public void computeStrikeRate() {
		if((wickets < 0)||(matches < 0)||(balls_bowled < 0)||(runs_conceded < 0)) {
			System.out.println("Error");
		}
		else if(matches == 0 && (runs_conceded > 0 || balls_bowled > 0)) {
			System.out.println("Error");
		}
		else {
			if(runs_conceded==0 || wickets==0) {
				System.out.println("Error");
			}
			else {
				System.out.println("Name:- "+getName());
				double StrikeRate = (double) runs_conceded/balls_bowled;
				System.out.println("Strike_Rate:- " +StrikeRate);
			}
		}
	}
}
