package day.four;

import java.util.Scanner;

public class CustomerDemo2 {

	public static void main(String[] args) {
		Bank bank = new Bank();
		int choice;
		
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1. Add Customer ");
			System.out.println("2. Display Customers");
			System.out.println("3. Display Customer By ID");
			System.out.println("4. Deposit Amount ");
			System.out.println("5. Withdraw "); 
			System.out.println("6. Transfer "); //id, amount to be read then check after withdraw amount >=1000
			System.out.println("7. E X I T");
			
			System.out.println("Enter your choice : ");
			choice = sc.nextInt();
			
			switch(choice){
			
			case 1:
				System.out.println("Enter first name : ");
				String firstName = sc.next();
				System.out.println("Enter last name : ");
				String lastName = sc.next();
				System.out.println("Enter address : ");
				String address = sc.next();
				System.out.println("Enter amount : ");
				double amount = sc.nextDouble();
				int id = bank.addCustomer(firstName, lastName, address, amount);
				System.out.println("Object created successfully .. id is "+id);
			break;	
			
			case 2: 
				Customer customers[] = bank.getAllCustomers();
				for(Customer customer : customers){
					if(customer!=null)
					System.out.println(customer);
				}
				break;
			
			case 3: 
				System.out.println("Enter id to display : ");
				id = sc.nextInt();
				Customer customer = bank.getCustomerById(id);
				System.out.println(customer);
				break;
				
			case 4: 
				System.out.println("Enter id to deposit :");
				id = sc.nextInt();
				System.out.println("Enter amount to deposit : ");
				amount = sc.nextDouble();
				String result = bank.deposit(id, amount);
				System.out.println(result);
				break;
				
			case 5:
				System.out.println("Enter id to withdraw :");
				id = sc.nextInt();
				System.out.println("Enter amount to withdraw : ");
				amount = sc.nextDouble();
				result = bank.withdraw(id, amount);
				System.out.println(result);
				break;
			}
		
		}while(choice < 6);

	}
}

