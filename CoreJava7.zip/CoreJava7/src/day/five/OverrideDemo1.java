package day.five;

class Parent1{
	public void show(){
		System.out.println("Hi! This is parent show...");
	}
}

class Child1 extends Parent1{
	public void show(){
		super.show();
		System.out.println("Hi! This is child show...");
	}
}

public class OverrideDemo1 {

	public static void main(String[] args) {
		
		Child1 child1 = new Child1();
		child1.show();
	}

}
