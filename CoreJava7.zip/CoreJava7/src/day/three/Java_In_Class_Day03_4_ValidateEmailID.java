package day.three;
public class Java_In_Class_Day03_4_ValidateEmailID {
	public static void main(String[] args) {
		String email = "tTESTMAIL@GMAIL.COM";	//"testmail@mailme.com";
		if (isValidMailID(email).equals("Valid")) {
			System.out.println("Valid EmailID");
		} else {
			System.out.println("Invalid EmailID");
		}
	}

	public static String isValidMailID(String email) {
		if (Character.isUpperCase(email.charAt(0)))
			return "-1";
		if (!Character.isLetter(email.charAt(0))) 
			return "-1";
		if (email.indexOf("@") == -1)
			return "-2";
		String temp = email.replace("@","");  //tTESTMAILGMAIL.COM"
		if ((email.length() - temp.length()) != 1)
			return "-3";
		
		if (!(email.endsWith(".com") || email.endsWith(".co.in")))
			return "-4";

		return "Valid";
	}
}
