package day.three;

public class AnagramsDemo1 {

	public static boolean isAnagrams(String str1,String str2){
		//Write ur code here...
		return true;
	}
	public static void main(String[] args) {
		String str1 = "CAT";
		String str2 = "ACT";
		//Above are anagrams
		
		System.out.println(isAnagrams(str1,str2));
	}
}
