package day.three;

import java.util.Scanner;

public class StringDemo2 {

	public static int vowelsCount(String str) {
		String vowels="AEIOUaeiou";
		int counter = 0;
		for(int i=0; i<str.length(); i++){
			if(vowels.contains(str.charAt(i)+""))
				counter++;
		}
		return counter;
	}
	public static int vowelsCount2(String str) {
		String vowels="AEIOUaeiou";
		char c[] = str.toCharArray();
		int counter = 0;
		for(int i=0; i<str.length(); i++){
			if(vowels.contains(c[i]+""))
				counter++;
		}
		return counter;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string : ");
		String str = sc.nextLine(); 
		int vowels = vowelsCount2(str);
		System.out.println(vowels);
	}
}

//input: PASHA	Output	=> 2
//input: India	Output => 3