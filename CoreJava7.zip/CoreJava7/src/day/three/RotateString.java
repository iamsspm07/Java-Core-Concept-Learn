package day.three;

public class RotateString {

	public static void rotate(String str,int pos){
		
		System.out.println(str.substring(str.length() - pos)+str.substring(0,str.length() - pos));
	}
	public static void main(String[] args) { 
		String str= "abcdef";
		rotate(str,1);   //defabc
	}

}
