package day.three;

import java.util.Arrays;

public class StringDemo1 {

	public static void main(String[] args) {
		String str = "Hello World";
		System.out.println(str.length());
		System.out.println(str.equals("hello world"));
		System.out.println(str.equalsIgnoreCase("hello world"));
		System.out.println(str.substring(0,2));
		System.out.println(str.substring(6,11));
		System.out.println(str.substring(6));
		System.out.println(str.charAt(6));
		System.out.println(str.indexOf('W'));
		
		String str2="DCABHEF";
		
		char c[] = str2.toCharArray();
		Arrays.sort(c);
		for(int i=0; i<c.length; i++)
			System.out.print(c[i]);
		
		str2 = new String(c);
		System.out.println(str2);
		
		String words[] = str.split(" ");
		System.out.println(words[0]);
		System.out.println(words[1]);
		
		String dob="21-2-2003";
		String dates[] = dob.split("-");
		for(int i=0; i<dates.length; i++)
			System.out.println(dates[i]);
		
		System.out.println(str.contains("World"));
	}
}
