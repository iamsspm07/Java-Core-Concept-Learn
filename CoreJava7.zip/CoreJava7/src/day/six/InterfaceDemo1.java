package day.six;


interface Inter1{
	int x = 100;
	void sum(int a,int b);//it is public by default
	
}

interface Inter2 {
	public void sub(int a,int b);
}

class Test{
	public void mul(int a,int b){
		System.out.println("The mul is : " + (a * b));
	}
}

class TestInter extends Test implements Inter1,Inter2 {

	@Override
	public void sub(int a,int b) {
		System.out.println("The sub is : "+(a - b));
	}

	@Override
	public void sum(int a,int b) {
		System.out.println("The sum is : "+(a + b));
	}
}

public class InterfaceDemo1 {

	public static void main(String[] args) {
		TestInter testInter = new TestInter();
		testInter.sub(10, 5);
		testInter.sum(10, 5);
		testInter.mul(10, 5);
	}
}

