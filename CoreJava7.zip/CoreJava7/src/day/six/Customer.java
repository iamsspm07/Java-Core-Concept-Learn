package day.six;
abstract public class Customer{
	protected int id;
	protected String firstName;
	protected String lastName;
	protected String address;
	protected double balance;
	
	private static int counter = 1001;//single copy variable or class variable
	
	public Customer(){
		this.id = counter++;
	}

	public Customer(String firstName, String lastName, String address, double balance) {
		this.id = counter++;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.balance = balance;
	}
	
	abstract public void showDetails();
	
	public String getFullName(){
		return firstName+" "+lastName;
	}
	
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getId() {
		return id;
	}
}