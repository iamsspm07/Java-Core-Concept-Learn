package day.seven;

import java.util.HashSet;

public class CollectionsDemo2 {

	public static void main(String[] args) {
		
		//It does not maintain the order of insertion
		HashSet <String>hashSet = new HashSet<String>(); //no type no size
		
		hashSet.add("AUSTRALIA");
		hashSet.add("BANGLADESH");
		hashSet.add("CHINA");
		hashSet.add("DUBAI");
		hashSet.add("ENGLAND");
		hashSet.add("INDIA");
		hashSet.add("USA");
		System.out.println(hashSet);
		
		hashSet.remove("CHINA");
		
		for(String str : hashSet){
			System.out.println(str);
		}
	}
}

/*
Collection (Group of Objects)
-----------------------------
Array


Drawbacks
---------
1) size if fixed (int a[] = new int[5]);
2) similler data type only possible
3) no underlaying data structure methods




*/