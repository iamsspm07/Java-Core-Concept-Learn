package day.seven;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo1 {

	public static void main(String[] args) {
		Map <String,Integer>map = new HashMap<String,Integer>();//here key must be unique
		map.put("SACHIN", 88);
		map.put("DHONI", 76);
		map.put("JADEJA", 99);
		map.put("KOHLI", 65);
		map.put("ROHITH", 64);
		map.put("SACHIN", 100);
		map.put("YUVI", 100);
		
		System.out.println(map);
		System.out.println(map.containsKey("PASHA"));
		System.out.println(map.containsKey("DHONI"));
		System.out.println(map.containsValue(0));
		System.out.println(map.containsValue(100));
		System.out.println(map.get("JADEJA"));
		Set set = map.keySet();
		System.out.println(set);
		Collection values = map.values();
		System.out.println(values);
	}
}
