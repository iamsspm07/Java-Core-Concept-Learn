package day.seven;

import java.util.HashSet;

public class CollectionsDemo1 {

	public static void main(String[] args) {
		
		HashSet hashSet = new HashSet(); //no type no size
		
		hashSet.add(101);
		hashSet.add("SACHIN");
		hashSet.add(9999.99);
		hashSet.add(102);
		hashSet.add("PASHA");
		hashSet.add(8989.89);
		
		System.out.println(hashSet);
		
		for(Object obj : hashSet){
			System.out.println(obj);
		}
	}
}

/*
Collection (Group of Objects)
-----------------------------
Array


Drawbacks
---------
1) size if fixed (int a[] = new int[5]);
2) similler data type only possible
3) no underlaying data structure methods




*/