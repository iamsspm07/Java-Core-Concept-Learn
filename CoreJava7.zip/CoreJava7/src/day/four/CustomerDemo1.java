package day.four;

public class CustomerDemo1 {
	public static void main(String[] args) {
		Customer customer1 = new Customer("SACHIN","TENDULKAR","50-50, EAST, MUMBAI",9999.99);
		System.out.println(customer1);//it automatically calls toString()
		customer1.setLastName("RAMESH TENDULKAR");
		System.out.println(customer1);
		
		Customer customer2 = new Customer("MS","DHINI","20-20, WEST, MUMBAI",9898.98);
		System.out.println(customer2);//it automatically calls toString()
		customer2.setAddress("10-10, SOUTH, MUMBAI");
		System.out.println(customer2.getAddress());
		
		Customer customer3 = new Customer();
		System.out.println(customer3);
		customer3.setFirstName("PASHA");
		customer3.setLastName("MD");
		customer3.setAddress("20-20, WEST, HYDERABAD");
		customer3.setBalance(87878.88);
		System.out.println(customer3);
	}
}
/*
1. private variable
2. constructors (default & paramterized)
3. toString()
4. getters & setters
5. static keyword
*/