package day.two;

import java.util.Scanner;

public class Demo {
	public static String createPattern(int rows){
		String result="";
		for(int i = 1; i <= rows; i++){
			for(int j = rows; j >= i; j--){
				result += " ";
			}
			for(int k=1; k<=i; k++){  //123
				result +=k;
			}
			for(int m=i-1; m>=1; m--){ //21
				result +=m;
			}	
			result +="\n";
		}
		return result;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int num = sc.nextInt();
		
		System.out.println(createPattern(num));
		
	}
}

/*
    1
   121
  12321
 1234321
123454321

*/