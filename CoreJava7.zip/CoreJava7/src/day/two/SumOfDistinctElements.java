package day.two;

import java.util.Scanner;

public class SumOfDistinctElements {

	public static boolean isDuplicate(int arr[],int num){
		int count = 0;
		for(int a: arr){
			if(a == num)
				count++;
		}
		return count > 1;
	}

	public static int getSumOfDistinctElements(int arr[]){
		int sum = 0;
		for(int a: arr){
			if(!isDuplicate(arr,a))
				sum += a;
		}
		return sum;
	}
	public static void main(String[] args) {	
		int a[] = new int[5]; //single dimensional array
		Scanner sc = new Scanner(System.in);
	
		
		System.out.println("Enter 5 numbers : ");
		for(int i=0; i<a.length; i++)
		a[i] = sc.nextInt();
		System.out.println(getSumOfDistinctElements(a));
		
	}

}
